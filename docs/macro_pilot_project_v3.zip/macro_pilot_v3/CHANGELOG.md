# CHANGELOG

## v3 (2026-04-30) — Defect fixes + improvements

### Defects Fixed
- **D1** `src/incremental_pca.py`: Fixed empty `pca_pc1_vs_pc2.json` (0 points).
  Pre-computed `pc2_vals` before list comprehension to avoid silent empty output
  from inline conditional inside `zip()`.
- **D2** `src/incremental_pca.py`: Fixed `pca_pc1_timeseries.json` all-zeros series.
  Script now always writes real PCA scores from `X_pca[:,0]`.
- **D3** `src/isolation_forest.py`: Fixed 1996 warm-start artefacts dominating top anomalies.
  Drops the first `max(lags + rolling_windows)` rows before fitting the model.
- **D4** `dvc.yaml`: Added `params: [preprocessing]` to the `validate` stage so DVC
  re-runs the stage when validation thresholds change.
- **D5** `dvc.yaml`: Added commented-out `autoencoder` stage stub to resolve the dangling
  `configs/autoencoder.yaml` config. Uncomment and implement `src/autoencoder.py` to activate.

### Improvements Applied
- **I2** `notebooks/macro_pilot_presentation_showcase.ipynb`: Rebuilt with 7 code cells.
  Now renders: metrics comparison table, PCA explained variance chart, Isolation Forest
  anomaly timeline, factor loading heatmap, changepoint timeline, experiment comparison
  table, and winner promotion flow.
- **I3** `docs/GETTING_STARTED.md`: Added Git vs DVC role split table under a new section.
- **I4** `docs/EXPERIMENTS.md`: Added mock `dvc exp show` output table with 5 experiment rows.
- **I5** `docs/PROMOTION.md`: Already contained `dvc exp apply` as critical Step 2 — confirmed present.
- **I7** `requirements.txt`: Added `factor-analyzer>=0.4` for varimax rotation support.

### Notes
- I1: `GETTING_STARTED.md` and `DEVELOPMENT.md` already had Purpose/Audience/What not to expect
  headers in v2 — confirmed present, no change needed.
- I6: `changepoint_regime_timeline.json` placeholder noted; run `dvc repro changepoint` to sync.
