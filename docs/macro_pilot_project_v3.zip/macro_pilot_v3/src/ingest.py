"""
ingest.py — Load raw macrodata.csv (FRED, 1996-2020) and write a clean interim CSV.

Key adaptations for the real Kaggle dataset:
  - The date column has no header; it is the first column with values like "1996-01".
  - We rename it to 'date' and parse it as a proper datetime (YYYY-MM → first of month).
  - Columns with > drop_threshold_missing fraction of NaN are dropped.
  - Remaining numeric NaNs are forward-filled then filled with the column median.

Fixes applied (v2):
  - Replaced deprecated fillna(method='ffill') with .ffill() to silence FutureWarning.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml


# ── FRED column descriptions (for logging / documentation) ──────────────────
FRED_COLS = {
    "RPI":       "Real Personal Income",
    "INDPRO":    "Industrial Production Index",
    "CE16OV":    "Civilian Employment 16+",
    "UNRATE":    "Unemployment Rate (%)",
    "PAYEMS":    "Total Nonfarm Payrolls (thousands)",
    "USGOOD":    "Goods-Producing Employment (thousands)",
    "USTPU":     "Trade/Transport/Utilities Employment (thousands)",
    "HOUST":     "Housing Starts (thousands)",
    "PERMIT":    "Building Permits (thousands)",
    "AMTMTI":    "All Mfg: Total Inventories",
    "AMTMNO":    "All Mfg: New Orders",
    "ACOGNO":    "Mfg New Orders: Consumer Goods",
    "AMDMUO":    "Mfg Unfilled Orders: Durable Goods",
    "BUSINV":    "Total Business Inventories",
    "ISRATIO":   "Inventory-to-Sales Ratio",
    "M1SL":      "M1 Money Supply",
    "M2SL":      "M2 Money Supply",
    "TOTRESNS":  "Total Reserves of Depository Institutions",
    "BUSLOANS":  "Commercial & Industrial Loans",
    "REALLN":    "Real Estate Loans",
    "DTCTHFNM":  "Total Consumer Credit",
    "FEDFUNDS":  "Federal Funds Rate (%)",
    "TB3MS":     "3-Month Treasury Bill Rate (%)",
    "GS5":       "5-Year Treasury Constant Maturity Rate (%)",
    "GS10":      "10-Year Treasury Constant Maturity Rate (%)",
    "AAA":       "Moody's Aaa Corporate Bond Yield (%)",
    "TB3SMFFM":  "3-Month T-Bill Minus Fed Funds Spread",
    "T1YFFM":    "1-Year Treasury Minus Fed Funds Spread",
}


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)
    with open("params.yaml") as f:
        params = yaml.safe_load(f)

    raw_path = Path(cfg["raw_path"])
    if not raw_path.exists():
        raise FileNotFoundError(
            f"Raw dataset not found at '{raw_path}'.\n"
            "Download 'macrodata.csv' from:\n"
            "  https://www.kaggle.com/datasets/devarshraval/us-macroeconomic-data-19962020-source-fred\n"
            "and place it under data/raw/macrodata.csv"
        )

    # ── Load ────────────────────────────────────────────────────────────────
    df = pd.read_csv(raw_path)

    # The first column has no name in the CSV — it contains YYYY-MM date strings.
    first_col = df.columns[0]
    df = df.rename(columns={first_col: "date"})

    # Parse date: "1996-01" → 1996-01-01
    df["date"] = pd.to_datetime(df["date"], format="%Y-%m")
    df = df.sort_values("date").reset_index(drop=True)

    print(f"Loaded {len(df)} rows × {len(df.columns)} columns from {raw_path}")
    print(f"Date range: {df['date'].min().date()} → {df['date'].max().date()}")

    # ── Drop high-missingness columns ────────────────────────────────────────
    thresh = params["preprocessing"]["drop_threshold_missing"]
    missing_rate = df.drop(columns=["date"]).isna().mean()
    drop_cols = missing_rate[missing_rate > thresh].index.tolist()
    if drop_cols:
        print(f"Dropping {len(drop_cols)} column(s) with >{thresh*100:.0f}% missing: {drop_cols}")
        df = df.drop(columns=drop_cols)

    # ── Fill remaining NaNs ──────────────────────────────────────────────────
    # FIX: use .ffill() instead of deprecated fillna(method='ffill')
    numeric_cols = df.select_dtypes(include="number").columns
    df[numeric_cols] = df[numeric_cols].ffill()
    for col in numeric_cols:
        df[col] = df[col].fillna(df[col].median())

    # ── Save ─────────────────────────────────────────────────────────────────
    out_path = Path(cfg["output_interim"])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Saved interim data → {out_path}  ({len(df)} rows × {len(df.columns)} columns)")

    # Log known FRED columns present
    known = [c for c in df.columns if c in FRED_COLS]
    print(f"Recognised FRED columns ({len(known)}): {known}")


if __name__ == "__main__":
    main()
