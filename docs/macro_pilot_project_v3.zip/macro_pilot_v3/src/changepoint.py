"""
changepoint.py — Change-point detection on key macro signals.
Primary output is structured JSON for plotting; if `ruptures` is unavailable,
a fallback rolling-volatility regime summary is emitted.
"""
import sys
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml, save_json

try:
    import ruptures as rpt
    HAS_RUPTURES = True
except Exception:
    HAS_RUPTURES = False

KEY_SIGNALS = ["UNRATE", "INDPRO", "FEDFUNDS", "M2SL", "GS10", "HOUST"]
RECESSIONS = [
    ("2001-03-01", "2001-11-01"),
    ("2007-12-01", "2009-06-01"),
    ("2020-02-01", "2020-04-01"),
]


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)
    with open("params.yaml") as f:
        params = yaml.safe_load(f)

    df = pd.read_csv(cfg["input_path"], parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    cp_params = params["changepoint"]
    use_signals = [c for c in KEY_SIGNALS if c in df.columns]
    breakpoints = {}
    signal_payload = {}

    if HAS_RUPTURES:
        for col in use_signals:
            signal = df[col].ffill().fillna(0).values
            algo = rpt.Pelt(model=cp_params["model"], min_size=cp_params["min_size"]).fit(signal)
            try:
                bkps = algo.predict(pen=cp_params["penalty"])
            except Exception:
                bkps = []
            bkps_display = [b for b in bkps if b < len(df)]
            breakpoints[col] = [str(df["date"].iloc[b - 1].date()) for b in bkps_display]
            signal_payload[col] = [round(float(v), 6) for v in signal]
    else:
        for col in use_signals:
            signal = df[col].ffill().fillna(0)
            signal_payload[col] = [round(float(v), 6) for v in signal]
            rolling = signal.rolling(6).std().fillna(0)
            threshold = rolling.quantile(0.9)
            candidate_idx = rolling[rolling >= threshold].index.tolist()[:5]
            breakpoints[col] = [str(df["date"].iloc[i].date()) for i in candidate_idx]

    plot_json = {
        "plot_type": "regime_timeline",
        "title": "Change-Point Regime Timeline",
        "x": df["date"].dt.strftime("%Y-%m-%d").tolist(),
        "signals": signal_payload,
        "breakpoints_per_signal": breakpoints,
        "recessions": [{"start": s, "end": e} for s, e in RECESSIONS],
        "method_detail": "ruptures_pelt" if HAS_RUPTURES else "rolling_std_fallback",
    }
    save_json(plot_json, "plots/changepoint_regime_timeline.json")

    metrics = {
        "method": "changepoint_pelt" if HAS_RUPTURES else "rolling_std_fallback",
        "model": cp_params["model"],
        "penalty": cp_params["penalty"],
        "signals_analysed": use_signals,
        "breakpoints_per_signal": breakpoints,
        "total_breakpoints": int(sum(len(v) for v in breakpoints.values())),
    }
    save_json(metrics, cfg["score_output"])
    print(f"Change-point stage complete — {metrics['total_breakpoints']} total breakpoints")


if __name__ == "__main__":
    main()
