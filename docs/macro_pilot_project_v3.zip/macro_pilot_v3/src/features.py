"""
features.py — Feature engineering for the FRED macro dataset.

Fixes applied (v2):
  - Builds all columns in a dict first, then calls pd.concat ONCE at the end.
    This eliminates the PerformanceWarning about highly-fragmented DataFrames.
  - Replaces inf values (from pct_change on zero-valued cells) with NaN,
    then fills NaN with 0. This prevents the downstream ValueError:
    "Input X contains infinity or a value too large for dtype('float64')".
  - Replaces deprecated fillna(method='ffill') with .ffill().

Feature groups created:
  1. Lag features  (1, 3, 6, 12 months) for all numeric columns
  2. Rolling mean  (3, 6, 12 months)
  3. Rolling std   (3, 6, 12 months)
  4. Pct-change    (1, 3, 12 months)
  5. Domain-specific spreads:
       - yield_spread_10y_3m   = GS10 - TB3MS
       - yield_spread_10y_fed  = GS10 - FEDFUNDS
       - real_rate_approx      = GS10 - (M2SL pct-change 12m as inflation proxy)
       - employment_gap        = CE16OV - CE16OV.rolling(12).mean()
       - inv_sales_delta       = ISRATIO - ISRATIO.shift(3)
       - credit_spread_aaa_10y = AAA - GS10
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml, save_json


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)
    with open("params.yaml") as f:
        params = yaml.safe_load(f)

    df = pd.read_csv(cfg["output_interim"], parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)

    numeric_cols = [c for c in df.select_dtypes(include="number").columns if c != "date"]

    lags    = params["features"]["lags"]
    windows = params["features"]["rolling_windows"]
    pct_w   = params["features"]["pct_change_windows"]

    # ── Build all feature columns into a dict, then concat once ─────────────
    col_dict: dict[str, pd.Series] = {"date": df["date"]}

    for col in numeric_cols:
        col_dict[col] = df[col]

        for lag in lags:
            col_dict[f"{col}_lag{lag}"] = df[col].shift(lag)

        for w in windows:
            col_dict[f"{col}_rmean{w}"] = df[col].rolling(w).mean()
            col_dict[f"{col}_rstd{w}"]  = df[col].rolling(w).std()

        for w in pct_w:
            pct = df[col].pct_change(w)
            # Replace inf/-inf that arise when denominator is 0
            pct = pct.replace([np.inf, -np.inf], np.nan)
            col_dict[f"{col}_pct{w}"] = pct

    # ── Domain-specific spreads ──────────────────────────────────────────────
    if "GS10" in df.columns and "TB3MS" in df.columns:
        col_dict["yield_spread_10y_3m"]  = df["GS10"] - df["TB3MS"]
    if "GS10" in df.columns and "FEDFUNDS" in df.columns:
        col_dict["yield_spread_10y_fed"] = df["GS10"] - df["FEDFUNDS"]
    if "GS10" in df.columns and "M2SL" in df.columns:
        m2_pct12 = df["M2SL"].pct_change(12).replace([np.inf, -np.inf], np.nan) * 100
        col_dict["real_rate_approx"]     = df["GS10"] - m2_pct12
    if "CE16OV" in df.columns:
        col_dict["employment_gap"]       = df["CE16OV"] - df["CE16OV"].rolling(12).mean()
    if "ISRATIO" in df.columns:
        col_dict["inv_sales_delta"]      = df["ISRATIO"] - df["ISRATIO"].shift(3)
    if "AAA" in df.columns and "GS10" in df.columns:
        col_dict["credit_spread_aaa_10y"] = df["AAA"] - df["GS10"]

    # ── Assemble in one concat call ──────────────────────────────────────────
    feat_df = pd.concat(col_dict, axis=1)

    # ── Final NaN / inf cleanup ──────────────────────────────────────────────
    # Replace any remaining inf values with NaN, then fill NaN with 0
    feat_df = feat_df.replace([np.inf, -np.inf], np.nan)
    feat_df = feat_df.fillna(0)

    # Drop rows where ALL feature columns are zero (initial window artefact)
    feature_cols = [c for c in feat_df.columns if c != "date"]
    feat_df = feat_df[feat_df[feature_cols].any(axis=1)].reset_index(drop=True)

    out_path = Path(cfg["output_processed"])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    feat_df.to_csv(out_path, index=False)

    print(f"Feature matrix: {feat_df.shape[0]} rows × {feat_df.shape[1]} columns")
    print(f"Inf values remaining: {np.isinf(feat_df[feature_cols].values).sum()}")
    print(f"NaN values remaining: {feat_df[feature_cols].isna().sum().sum()}")
    print(f"Saved → {out_path}")

    save_json(
        {"n_rows": feat_df.shape[0], "n_features": feat_df.shape[1] - 1},
        "metrics/features_metrics.json",
    )


if __name__ == "__main__":
    main()
