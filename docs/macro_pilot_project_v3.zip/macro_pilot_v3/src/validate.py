"""
validate.py — Data quality validation for the FRED macro dataset (1996-2020).

Checks performed:
  1. Row count and date continuity (monthly frequency, no gaps)
  2. Missingness per column
  3. Outlier detection (z-score > 4) per numeric column
  4. Monotonicity check for cumulative series (PAYEMS, M2SL, BUSLOANS, REALLN)
  5. Rate columns bounded to plausible ranges
  6. Summary quality score (0-100)

Fixes applied (v2):
  - PAYEMS, CE16OV, BUSLOANS, REALLN are NOT strictly monotone in the real FRED
    data — they decline sharply during recessions (2001, 2008-09, 2020).
    The monotonicity check now uses a much higher threshold (>30 violations)
    before flagging, and CE16OV is removed from the monotone list entirely
    as it is a labour-force participation stock that fluctuates freely.
  - The 'P/E' and 'Dividend Yield' columns (from the merged Kaggle dataset)
    are excluded from the z-score check since they are not FRED indicators
    and have very different scales.
  - Removed deprecated fillna(method=) usage.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml, save_json

# Only flag series that should be broadly non-decreasing over multi-decade spans.
# Threshold: flag only if more than 30 months show a decline > 0.5 units
# (recessions cause short-term dips, but not sustained multi-decade declines).
MONOTONE_COLS = ["M2SL", "BUSLOANS", "REALLN", "PAYEMS"]
MONOTONE_THRESHOLD = 30   # number of negative-diff months before flagging

# Interest-rate columns — valid range roughly [-2, 25] %
RATE_COLS = ["FEDFUNDS", "TB3MS", "GS5", "GS10", "AAA", "TB3SMFFM", "T1YFFM"]
RATE_RANGE = (-2.0, 25.0)

# Unemployment rate — valid range [0, 25] %
UNRATE_RANGE = (0.0, 25.0)

# Columns to skip in z-score check (non-FRED, different scale)
SKIP_ZSCORE = {"P/E", "Dividend Yield"}


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)

    df = pd.read_csv(cfg["output_interim"], parse_dates=["date"])
    numeric_cols = [c for c in df.select_dtypes(include="number").columns
                    if c not in SKIP_ZSCORE]

    issues: list[str] = []
    metrics: dict = {}

    # 1. Row count
    metrics["n_rows"] = int(len(df))
    metrics["n_cols"] = int(len(df.columns))
    metrics["date_min"] = str(df["date"].min().date())
    metrics["date_max"] = str(df["date"].max().date())

    # 2. Date continuity
    expected_months = pd.date_range(df["date"].min(), df["date"].max(), freq="MS")
    missing_dates = set(expected_months) - set(df["date"])
    metrics["missing_date_count"] = len(missing_dates)
    if missing_dates:
        issues.append(f"{len(missing_dates)} missing month(s) in date sequence")

    # 3. Missingness
    miss = df[numeric_cols].isna().mean().round(4)
    metrics["missingness"] = miss.to_dict()
    high_miss = miss[miss > 0.05].index.tolist()
    if high_miss:
        issues.append(f"Columns with >5% missing: {high_miss}")

    # 4. Z-score outliers (|z| > 4) — skip non-FRED columns
    z_scores = ((df[numeric_cols] - df[numeric_cols].mean()) / df[numeric_cols].std()).abs()
    outlier_counts = (z_scores > 4).sum().to_dict()
    metrics["outlier_counts_z4"] = {k: int(v) for k, v in outlier_counts.items()}
    flagged = [k for k, v in outlier_counts.items() if v > 0]
    if flagged:
        # Informational only — extreme values are expected in macro data (COVID, GFC)
        metrics["outlier_info"] = f"Columns with z>4 values (expected in macro data): {flagged}"

    # 5. Monotonicity check — only flag if violations exceed threshold
    mono_violations = {}
    for col in MONOTONE_COLS:
        if col in df.columns:
            diffs = df[col].diff().dropna()
            n_neg = int((diffs < -0.5).sum())
            mono_violations[col] = n_neg
            if n_neg > MONOTONE_THRESHOLD:
                issues.append(
                    f"{col}: {n_neg} monthly decreases — possible data quality issue "
                    f"(threshold: {MONOTONE_THRESHOLD})"
                )
    metrics["monotonicity_violations"] = mono_violations

    # 6. Rate range check
    rate_issues = {}
    for col in RATE_COLS:
        if col in df.columns:
            out_of_range = int(((df[col] < RATE_RANGE[0]) | (df[col] > RATE_RANGE[1])).sum())
            rate_issues[col] = out_of_range
            if out_of_range > 0:
                issues.append(f"{col}: {out_of_range} values outside {RATE_RANGE}")
    metrics["rate_range_violations"] = rate_issues

    if "UNRATE" in df.columns:
        ur_issues = int(((df["UNRATE"] < UNRATE_RANGE[0]) | (df["UNRATE"] > UNRATE_RANGE[1])).sum())
        metrics["unrate_range_violations"] = ur_issues
        if ur_issues > 0:
            issues.append(f"UNRATE: {ur_issues} values outside {UNRATE_RANGE}")

    # 7. Quality score
    deductions = len(issues) * 5
    metrics["quality_score"] = max(0, 100 - deductions)
    metrics["issues"] = issues
    metrics["status"] = "PASS" if not issues else "WARN"

    save_json(metrics, cfg["metrics_path"])
    print(f"Validation complete — status: {metrics['status']}, score: {metrics['quality_score']}")
    if issues:
        for i in issues:
            print(f"  WARN: {i}")


if __name__ == "__main__":
    main()
