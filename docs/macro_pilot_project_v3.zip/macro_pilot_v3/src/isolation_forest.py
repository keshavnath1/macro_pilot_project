"""\nisolation_forest.py — Anomaly detection using Isolation Forest on FRED macro features.\n\nPrimary outputs are structured files:\n  - metrics/isolation_forest_metrics.json\n  - plots/iforest_anomaly_timeline.json\n  - plots/iforest_top_anomalies.json\n  - data/interim/iforest_scores.csv\n\nFix applied (v3):\n  D3 — Top anomalies were dominated by 1996-01/02/03 warm-start artefacts.\n       Root cause: lag/rolling features are zero-filled for the first\n       max(lags + rolling_windows) rows, making them structurally different.\n       Fix: drop those rows before fitting the model.\n"""
import sys
from pathlib import Path

import pandas as pd
import yaml
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml, save_json, save_df

KEY_SIGNALS = ["UNRATE", "INDPRO", "FEDFUNDS", "M2SL", "GS10", "HOUST"]
RECESSIONS = [
    ("2001-03-01", "2001-11-01"),
    ("2007-12-01", "2009-06-01"),
    ("2020-02-01", "2020-04-01"),
]


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)
    with open("params.yaml") as f:
        params = yaml.safe_load(f)

    df = pd.read_csv(cfg["input_path"], parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    feature_cols = [c for c in df.select_dtypes(include="number").columns if c != "date"]

    # FIX D3: drop warm-start artefact rows (lag/rolling window fill zeros)
    warmup = max(
        params["features"]["lags"] + params["features"]["rolling_windows"]
    )
    df = df.iloc[warmup:].reset_index(drop=True)

    import numpy as np
    X = df[feature_cols].fillna(0).replace([np.inf, -np.inf], 0).values
    X_scaled = StandardScaler().fit_transform(X)

    iso_params = params["isolation_forest"]
    model = IsolationForest(
        n_estimators=iso_params["n_estimators"],
        contamination=iso_params["contamination"],
        random_state=iso_params["random_state"],
        n_jobs=-1,
    )
    model.fit(X_scaled)
    scores = model.decision_function(X_scaled)
    labels = model.predict(X_scaled)
    df["anomaly_score"] = -scores
    df["is_anomaly"] = (labels == -1).astype(int)

    save_df(df[["date", "anomaly_score", "is_anomaly"]], "data/interim/iforest_scores.csv")

    timeline = {
        "plot_type": "multi_series_timeline",
        "title": "Isolation Forest Anomaly Timeline",
        "date_column": "date",
        "x": df["date"].dt.strftime("%Y-%m-%d").tolist(),
        "series": {
            "anomaly_score": [round(float(v), 6) for v in df["anomaly_score"]],
        },
        "flagged_points": df.loc[df["is_anomaly"] == 1, ["date", "anomaly_score"]].assign(
            date=lambda x: x["date"].dt.strftime("%Y-%m-%d"),
            anomaly_score=lambda x: x["anomaly_score"].round(6)
        ).to_dict(orient="records"),
        "reference_signals": {
            col: [None if pd.isna(v) else round(float(v), 6) for v in df[col]]
            for col in KEY_SIGNALS if col in df.columns
        },
        "recessions": [{"start": s, "end": e} for s, e in RECESSIONS],
    }
    save_json(timeline, "plots/iforest_anomaly_timeline.json")

    top20 = df.nlargest(20, "anomaly_score")[["date", "anomaly_score"]].sort_values("date")
    top_json = {
        "plot_type": "barh",
        "title": "Top 20 Most Anomalous Months",
        "items": top20.assign(date=top20["date"].dt.strftime("%Y-%m")).to_dict(orient="records"),
    }
    save_json(top_json, "plots/iforest_top_anomalies.json")

    metrics = {
        "method": "isolation_forest",
        "n_samples": int(len(df)),
        "n_features": int(len(feature_cols)),
        "n_anomalies": int(df["is_anomaly"].sum()),
        "contamination": iso_params["contamination"],
        "anomaly_rate": float(round(df["is_anomaly"].mean(), 4)),
        "mean_score": float(round(df["anomaly_score"].mean(), 4)),
        "max_score": float(round(df["anomaly_score"].max(), 4)),
        "top5_anomaly_months": df.nlargest(5, "anomaly_score")["date"].dt.strftime("%Y-%m").tolist(),
    }
    save_json(metrics, cfg["score_output"])
    print(f"Isolation Forest complete — {metrics['n_anomalies']} anomalies detected")


if __name__ == "__main__":
    main()
