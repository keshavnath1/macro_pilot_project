"""
factor_analysis.py — Factor Analysis on FRED macro features.
Primary outputs are structured JSON files for plotting.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from sklearn.decomposition import FactorAnalysis
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml, save_json

BASE_FRED_COLS = [
    "RPI", "INDPRO", "CE16OV", "UNRATE", "PAYEMS", "USGOOD", "USTPU",
    "HOUST", "PERMIT", "AMTMTI", "AMTMNO", "ACOGNO", "AMDMUO", "BUSINV", "ISRATIO",
    "M1SL", "M2SL", "TOTRESNS", "BUSLOANS", "REALLN", "DTCTHFNM",
    "FEDFUNDS", "TB3MS", "GS5", "GS10", "AAA", "TB3SMFFM", "T1YFFM",
]


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)
    with open("params.yaml") as f:
        params = yaml.safe_load(f)

    df = pd.read_csv(cfg["input_path"], parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    use_cols = [c for c in BASE_FRED_COLS if c in df.columns]
    X = df[use_cols].ffill().fillna(0).values
    X_scaled = StandardScaler().fit_transform(X)

    n_factors = min(params["factor_analysis"]["n_factors"], len(use_cols))
    fa = FactorAnalysis(n_components=n_factors, random_state=42)
    fa.fit(X_scaled)
    loadings = pd.DataFrame(fa.components_.T, index=use_cols, columns=[f"Factor {i+1}" for i in range(n_factors)])
    scores = pd.DataFrame(fa.transform(X_scaled), columns=[f"Factor {i+1}" for i in range(n_factors)])
    scores.insert(0, "date", df["date"].dt.strftime("%Y-%m-%d"))

    heatmap_json = {
        "plot_type": "heatmap",
        "title": "Factor Loadings Heatmap",
        "x_labels": loadings.columns.tolist(),
        "y_labels": loadings.index.tolist(),
        "z": [[round(float(v), 6) for v in row] for row in loadings.values.tolist()],
    }
    save_json(heatmap_json, "plots/factor_loading_heatmap.json")

    series = {col: [round(float(v), 6) for v in scores[col]] for col in scores.columns if col != "date"}
    scores_json = {
        "plot_type": "multi_line",
        "title": "Factor Scores Over Time",
        "x": scores["date"].tolist(),
        "series": series,
    }
    save_json(scores_json, "plots/factor_scores_over_time.json")

    metrics = {
        "method": "factor_analysis",
        "n_factors": n_factors,
        "n_columns_used": len(use_cols),
        "mean_noise_variance": round(float(np.mean(fa.noise_variance_)), 4),
        "top_loadings_factor1": loadings["Factor 1"].abs().nlargest(5).index.tolist(),
    }
    save_json(metrics, cfg["score_output"])
    print(f"Factor Analysis complete — {n_factors} factors")


if __name__ == "__main__":
    main()
