"""\nincremental_pca.py — Incremental PCA on the full feature matrix.\nPrimary outputs are structured JSON files for plotting.\n\nFixes applied (v3):\n  D1 — pca_pc1_vs_pc2.json was empty (0 points).\n       Root cause: inline conditional inside zip() was never evaluated as a\n       separate variable, causing silent empty output.\n       Fix: pre-compute pc2_vals before the list comprehension.\n  D2 — pca_pc1_timeseries.json series was all zeros.\n       Root cause: stage not re-run after JSON redesign; placeholder zeros\n       were committed. Fix: script now always writes real PCA scores.\n"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from sklearn.decomposition import IncrementalPCA
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).parent))
from common import cli, load_yaml, save_json

RECESSIONS = [
    ("2001-03-01", "2001-11-01"),
    ("2007-12-01", "2009-06-01"),
    ("2020-02-01", "2020-04-01"),
]


def main() -> None:
    args = cli()
    cfg = load_yaml(args.config)
    with open("params.yaml") as f:
        params = yaml.safe_load(f)

    df = pd.read_csv(cfg["input_path"], parse_dates=["date"]).sort_values("date").reset_index(drop=True)
    feature_cols = [c for c in df.select_dtypes(include="number").columns if c != "date"]
    X = df[feature_cols].fillna(0).replace([np.inf, -np.inf], 0).values
    X_scaled = StandardScaler().fit_transform(X)

    n_components = min(params["incremental_pca"]["n_components"], X_scaled.shape[1], X_scaled.shape[0])
    batch_size = params["incremental_pca"]["batch_size"]
    ipca = IncrementalPCA(n_components=n_components, batch_size=batch_size)
    X_pca = ipca.fit_transform(X_scaled)
    explained = ipca.explained_variance_ratio_
    cumulative = np.cumsum(explained)

    save_json({
        "plot_type": "bar_line_combo",
        "title": "PCA Explained Variance",
        "components": list(range(1, n_components + 1)),
        "explained_variance_ratio": [round(float(v), 6) for v in explained],
        "cumulative_variance_ratio": [round(float(v), 6) for v in cumulative],
        "thresholds": {"80pct": 0.8},
    }, "plots/pca_explained_variance.json")

    # FIX D2: write real X_pca[:,0] scores (not placeholder zeros)
    save_json({
        "plot_type": "line",
        "title": "PC1 Over Time",
        "x": df["date"].dt.strftime("%Y-%m-%d").tolist(),
        "series": {"PC1": [round(float(v), 6) for v in X_pca[:, 0]]},
        "recessions": [{"start": s, "end": e} for s, e in RECESSIONS],
    }, "plots/pca_pc1_timeseries.json")

    # FIX D1: pre-compute pc2_vals before list comprehension to avoid silent
    # empty output from inline conditional inside zip()
    pc2_vals = X_pca[:, 1] if n_components >= 2 else np.zeros(len(df))
    scatter_points = [
        {
            "PC1":  round(float(a), 6),
            "PC2":  round(float(b), 6),
            "date": d.strftime("%Y-%m-%d"),
            "year": int(d.year),
        }
        for a, b, d in zip(X_pca[:, 0], pc2_vals, df["date"])
    ]
    save_json({
        "plot_type": "scatter",
        "title": "PC1 vs PC2 (coloured by year)",
        "points": scatter_points,
    }, "plots/pca_pc1_vs_pc2.json")

    metrics = {
        "method": "incremental_pca",
        "n_components": n_components,
        "explained_variance_ratio": [round(float(v), 4) for v in explained],
        "cumulative_variance_at_k": [round(float(v), 4) for v in cumulative],
        "components_for_80pct": int(np.searchsorted(cumulative, 0.80) + 1),
    }
    save_json(metrics, cfg["score_output"])
    print(f"Incremental PCA complete — {n_components} components, "
          f"{len(scatter_points)} scatter points written")


if __name__ == "__main__":
    main()
