# Macro Analytics Pilot — Git + DVC Showcase

This project demonstrates two things at the same time:

1. a reproducible macro analytics pipeline
2. a team collaboration pattern for Git + DVC experiments

## Main message

- **Git chooses the winner**
- **DVC preserves the evidence**

## Current stages

- ingest
- validate
- features
- isolation_forest
- factor_analysis
- incremental_pca
- changepoint

## Primary artifact rule

- `metrics/*.json` → summary metrics
- `plots/*.json` → plot-ready structured data
- optional rendered PNG/HTML only as secondary presentation output

## Start here

Read the documentation in `docs/` in this order:

1. `GETTING_STARTED.md`
2. `DEVELOPMENT.md`
3. `EXPERIMENTS.md`
4. `PROMOTION.md`
5. `PRESENTATION_GUIDE.md`

## Run the pipeline

```bash
dvc repro
```

## Run an experiment

```bash
git checkout -b exp/factor-analysis-v2
dvc exp run -n factor-v6 --set-param factor_analysis.n_factors=6
dvc exp save --name factor-v6
dvc exp show
dvc metrics show
dvc plots show
```
