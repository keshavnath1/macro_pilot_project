# PRESENTATION_GUIDE.md

**Purpose:** Help you present the project and notebook story clearly to a team  
**Audience:** Presenters, demo owners, leads  
**When to use this doc:** Before demos, walkthroughs, onboarding sessions  
**What not to expect from this doc:** Full coding details for every stage

---

## Core presentation message

> **Git chooses the winner. DVC preserves the evidence.**

That should be the anchor sentence for the whole presentation.

---

## Layman explanation

“We are showing how a team can safely try multiple data experiments. Git keeps the team’s work organized. DVC keeps the datasets, metrics, plots, and outputs organized. Together they help the team choose which experiment actually wins.”

---

## Intermediate explanation

“This project demonstrates a branch-based experiment workflow. Developers isolate ideas in Git branches, run reproducible DVC stages and experiments, compare JSON metrics and plot data, and then use Git merge or tags to declare the accepted winner.”

---

## Advanced explanation

“This is an ML collaboration pattern where Git governs code lineage, review, merges, and release markers, while DVC governs data lineage, pipeline reproducibility, artifact lineage, and experiment comparison tied to branch/commit baseline state.”

---

## Suggested live demo flow

1. Explain why ML workflow is different  
2. Show the current macro pilot pipeline  
3. Explain Git vs DVC responsibilities  
4. Show branch-based parallel experiments  
5. Show DVC comparison commands  
6. Show winner flow: apply -> commit -> merge/tag  
7. Explain what `main` becomes after merge  
8. End with local-only DVC vs optional S3-backed DVC

---

## Recommended notebook story

The notebook should be a guided story, not a heavy training notebook.

Suggested sections:
1. Why ML workflow is different
2. What this macro pilot project does
3. Git vs DVC responsibilities
4. Branch-based experiment workflow
5. Running named experiments
6. Comparing metrics and plot data
7. Winner flow: apply, commit, merge, tag
8. Local-only DVC vs optional S3-backed DVC
9. Final operating model

---

## Storage options

### Local-only DVC (default)
Best for demos, learning, and small-team use.

### Optional S3-backed DVC
Useful when multiple machines need shared DVC-managed storage.

Important message:
Even with S3-backed DVC, Git still chooses the winner.
S3 changes storage, not decision-making.

---

## Likely audience questions

### Why not Git alone?
Because Git is great for code and decisions, but weak for large data, metrics, plot data, and reproducible pipeline artifacts.

### Why not DVC alone?
Because DVC does not replace branch review, commit history, merge policy, or tags. It complements Git.

### What is the winner in this system?
The winner is the state the team accepts via Git merge or Git tag, backed by DVC evidence.

### Can `main` still compare against old experiments?
Yes, if those experiments were preserved as saved refs, branches, tags, or committed states.

---

## What you learned in this doc

- the strongest message for presenting the project
- layman, intermediate, and advanced wording
- the notebook story structure
- the demo flow and likely Q&A

## Read this next

Go back to **GETTING_STARTED.md** if you want to present from the top, or open the presentation notebook.

## When to come back to this doc

Come back before team demos or stakeholder walkthroughs.
