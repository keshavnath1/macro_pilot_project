# DEVELOPMENT.md

**Purpose:** Explain repo structure, config ownership, current DVC pipeline, and day-to-day dev workflow  
**Audience:** Developers, maintainers, technical contributors  
**When to use this doc:** When changing code, configs, stages, or outputs  
**What not to expect from this doc:** Winner-selection policy or presentation script

---

## Repo structure

```text
macro_pilot_refactored/
├── configs/
├── data/
│   ├── raw/
│   ├── interim/
│   └── processed/
├── docs/
├── metrics/
├── plots/
├── reports/
├── notebooks/
├── src/
├── dvc.yaml
├── params.yaml
├── README.md
└── requirements.txt
```

---

## What goes in Git vs DVC

| Git | DVC |
|---|---|
| source code | raw data |
| configs | processed data |
| docs | metrics |
| notebook structure | plot-ready JSON/CSV |
| branch/tag history | artifacts and stage outputs |
| `dvc.yaml`, `.dvc` refs | experiment evidence |

---

## Current exact stage commands

| Stage | Exact command |
|---|---|
| `ingest` | `python src/ingest.py --config configs/base.yaml` |
| `validate` | `python src/validate.py --config configs/base.yaml` |
| `features` | `python src/features.py --config configs/base.yaml` |
| `isolation_forest` | `python src/isolation_forest.py --config configs/isolation_forest.yaml` |
| `factor_analysis` | `python src/factor_analysis.py --config configs/factor_analysis.yaml` |
| `incremental_pca` | `python src/incremental_pca.py --config configs/incremental_pca.yaml` |
| `changepoint` | `python src/changepoint.py --config configs/changepoint.yaml` |

---

## Config philosophy

### `params.yaml`
Use for experiment knobs that you want to sweep and compare.

Examples:
- contamination
- factor count
- PCA component count
- changepoint penalty
- feature lag windows

### `configs/base.yaml`
Use for shared project defaults.

### method-specific YAMLs
Use for stage ownership and stage wiring.

---

## Daily development loop

```text
create branch
  -> change script or config
  -> run small stage locally
  -> inspect metrics/plot JSON
  -> commit
  -> review
```

Useful commands:

```bash
dvc repro
dvc repro features
dvc repro factor_analysis
dvc exp run -n factor-v6 --set-param factor_analysis.n_factors=6
```

---

## Script-first rule

Production and reproducible pipeline logic should live in `src/`.

Notebooks are for:
- exploration
- storytelling
- demo walkthroughs
- workflow explanation

They should not be the only source of truth for stage execution.

---

## Output design rule

Primary outputs should be structured:
- `metrics/*.json`
- `plots/*.json`
- optional CSV when easier for plotting tables/scatter points

Avoid PNG as the canonical analytical artifact.

---

## What you learned in this doc

- the repo layout
- what lives in Git versus DVC
- the exact current stage commands
- how config ownership is split
- the script-first workflow and output design rule

## Read this next

Read **EXPERIMENTS.md**.

## When to come back to this doc

Come back when changing scripts, configs, stage outputs, or repo structure.
