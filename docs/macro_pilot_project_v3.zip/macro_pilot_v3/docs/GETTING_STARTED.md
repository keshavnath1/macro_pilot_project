# GETTING_STARTED.md

**Purpose:** Explain the project in plain language and show the full beginner entry point  
**Audience:** New team members, demo audience, beginners  
**When to use this doc:** First read  
**What not to expect from this doc:** Full DVC internals or all merge/tag edge cases

---

## Why ML workflow is different

Machine learning work is different from normal software work because:
- experiments are slow
- experiments are metrics-driven
- results depend on code **and** data **and** outputs
- reproducibility matters more than just source-code history

A useful framing for this project is:

> **Experiment = code + outputs + dataset**

That means Git alone is not enough.

---

## What this project is

This is a **macro analytics pilot** that demonstrates both:
1. a reproducible analytics pipeline
2. a team workflow for comparing experiments with Git + DVC

Current analytics methods in the project:
- Isolation Forest
- Factor Analysis
- Incremental PCA
- Change-point detection
- optional future extensions like autoencoders, random projection, and state-space models

---

## Main message

- **Git chooses the winner**
- **DVC preserves the evidence**

---

## Git vs DVC role split

This is the most important mental model for the whole project.

| Responsibility | Git | DVC |
|---|:---:|:---:|
| Source code | Yes | No |
| Branches and commits | Yes | No |
| Merge and review decisions | Yes | No |
| Tags and winner declarations | Yes | No |
| Raw dataset | No | Yes |
| Processed / interim data | No | Yes |
| Summary metrics (`metrics/*.json`) | No | Yes |
| Plot-ready outputs (`plots/*.json`) | No | Yes |
| Reproducible pipeline stages | No | Yes |
| Experiment evidence (scores, artifacts) | No | Yes |
| Experiment comparison (`dvc exp show`) | No | Yes |

The key insight: **Git decides which experiment wins. DVC preserves the evidence that justifies the decision.**

---

## Big-picture flow

```text
raw data
  -> ingest
  -> validate
  -> features
  -> method stages
  -> metrics + plot data + artifacts
  -> compare experiments
  -> merge or tag winner
```

---

## Local-first default

The default showcase mode is **local-only DVC**:
- code and docs in Git
- data and outputs in DVC
- everything stored locally

That keeps setup simple for learning and demos.

---

## Current project stage map

| Stage | Purpose |
|---|---|
| `ingest` | prepare raw macro dataset for pipeline use |
| `validate` | generate data-quality metrics |
| `features` | create lag/rolling/pct-change feature matrix |
| `isolation_forest` | anomaly detection |
| `factor_analysis` | latent factor discovery |
| `incremental_pca` | scalable dimensionality reduction |
| `changepoint` | structural break / regime analysis |

---

## Artifact rule

This regenerated project uses:
- `metrics/*.json` for summary metrics
- `plots/*.json` for plot-ready structured data
- optional rendered PNG/HTML only as secondary presentation outputs

That means charts can be recreated later from JSON without depending on saved PNGs.

---

## What you learned in this doc

- why ML workflow is different from normal software workflow
- what this macro pilot project does
- the Git vs DVC role split
- the current pipeline at a high level
- why JSON/CSV artifacts are better than PNG-first design

## Read this next

Read **DEVELOPMENT.md**.

## When to come back to this doc

Come back when onboarding a new teammate or when you need the plain-English project story again.
