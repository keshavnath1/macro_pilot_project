# EXPERIMENTS.md

**Purpose:** Explain branch-based experimentation, DVC experiment refs, and team comparison workflow  
**Audience:** ML engineers, data scientists, reviewers  
**When to use this doc:** When running or comparing experiments  
**What not to expect from this doc:** Final release policy or full presentation script

---

## Main idea

A branch isolates the idea.  
DVC preserves the evidence.

That means:
- Git gives the experiment a code/config baseline
- DVC stores metrics, plots, and outputs tied to that baseline

---

## Experiments are tied to Git baseline state

This is the key concept.

When you run an experiment on a branch:
- the **branch/commit** defines the code and config state
- DVC experiment refs preserve the outputs for that state
- metrics and plots are meaningful because they are tied to a known Git baseline

Simple mental model:

```text
branch = proposal
experiment ref = evidence for that proposal
main = accepted baseline
```

---

## Example branch names

- `exp/isolation-forest-baseline`
- `exp/factor-analysis-v2`
- `exp/xgb-window-shift`
- `feature/add-change-point-stage`
- `release/demo-v1`

---

## Example experiment commands

```bash
git checkout -b exp/isolation-forest-baseline
dvc exp run -n iforest-baseline
dvc exp save --name iforest-baseline
```

```bash
git checkout -b exp/factor-analysis-v2
dvc exp run -n factor-v6 --set-param factor_analysis.n_factors=6
dvc exp save --name factor-v6
```

Compare all saved experiments:

```bash
dvc exp show
dvc metrics show
dvc plots show
```

Example `dvc exp show` output — what the team sees when comparing experiments side by side:

```
┌──────────────────────────────┬──────────────┬─────────────┬────────────────┐
│ Experiment                   │ n_anomalies  │ n_factors   │ cum_var_80pct  │
├──────────────────────────────┼──────────────┼─────────────┼────────────────┤
│ workspace                    │ 9            │ 5           │ 7              │
│ iforest-baseline             │ 9            │ –           │ –              │
│ iforest-contamination-0.05   │ 15           │ –           │ –              │
│ factor-v5                    │ –            │ 5           │ 7              │
│ factor-v6                    │ –            │ 6           │ 6              │
└──────────────────────────────┴──────────────┴─────────────┴────────────────┘
```

This table is the **evidence layer** — it tells the team which experiment produced the best metrics before anyone touches `main`.

---

## Parallel team workflow

```text
main
  -> dev A creates exp/isolation-forest-baseline
  -> dev B creates exp/factor-analysis-v2
  -> dev C creates exp/xgb-window-shift
  -> each runs DVC experiments
  -> team compares metrics and plot data
```

This works because:
- Git isolates branch history
- DVC isolates experiment evidence

---

## What `main` sees after merge

After a winning branch is merged:
- `main` becomes the new accepted baseline
- `main` can reproduce the accepted winner state
- `main` can still compare against saved experiment refs **if those refs were preserved**

Important:
- `main` should not be treated as containing every experiment as current state
- historical experiments remain comparable only if preserved as refs, branches, tags, or committed states

---

## Best practice

- branches hold exploration
- saved experiment refs hold experiment evidence
- `main` holds the accepted baseline
- tags mark winners and milestones

---

## What you learned in this doc

- how branch-based experiments work in this project
- that DVC experiment refs are tied to Git baseline state
- how to name, run, save, and compare experiments
- what a real `dvc exp show` comparison looks like
- what `main` can and cannot do after merge

## Read this next

Read **PROMOTION.md**.

## When to come back to this doc

Come back when the team is running side-by-side experiments or asking how saved experiment refs survive after merge.
