# PROMOTION.md

**Purpose:** Explain validation, winner selection, merge/tag strategy, and accepted-baseline behavior  
**Audience:** Leads, maintainers, reviewers, experiment owners  
**When to use this doc:** When selecting or formalizing a winner  
**What not to expect from this doc:** Full stage implementation detail

---

## Winner flow

```text
run named experiment on branch
  -> dvc exp save --name <name>          (save experiment ref)
  -> dvc exp show / dvc metrics show     (compare evidence)
  -> team chooses winner
  -> dvc exp apply <name>                ← CRITICAL STEP
  -> git add + git commit on branch
  -> git merge to main
  -> git tag winner/<name>
  -> dvc push                            (upload artifacts to remote)
```

> **Why `dvc exp apply` is the critical step:** Merging the Git branch alone does **not** restore DVC-tracked artifacts (metrics, plots, model files). You must run `dvc exp apply <experiment-name>` first to restore the DVC workspace to the winning experiment state before committing. Skipping this step is the most common mistake when first adopting DVC experiments.

---

## Best practice before merge

Full step-by-step winner promotion sequence:

```bash
# Step 1 — switch to the winning branch
git checkout exp/isolation-forest-baseline

# Step 2 — CRITICAL: restore DVC artifacts to the winning experiment state
#           Without this, the merge will not include DVC-tracked outputs.
dvc exp apply iforest-baseline

# Step 3 — commit the restored DVC state on the branch
git add .
git commit -m "Promote winning experiment: iforest-baseline"

# Step 4 — merge to main
git checkout main
git merge exp/isolation-forest-baseline

# Step 5 — push DVC artifacts to remote storage
dvc push

# Step 6 — tag the winner and push tags
git tag winner/isolation-forest-v1
git tag milestone/demo-ready-v1
git push --tags
```

---

## Validation checklist before winner declaration

- code/config diff is understandable
- experiment is reproducible
- metrics were reviewed
- plot-ready outputs were reviewed
- branch intent is clear
- winner is not chosen on one metric alone
- team agrees on interpretation

---

## Merge vs tag

### Merge to `main`
Use when the branch should become the new accepted baseline.

### Tag the winner
Use when you want to mark an important experiment state or milestone explicitly.

---

## What `main` gets after merge

After merge:
- `main` gets the accepted winner state
- `main` becomes the new reference baseline
- `main` can reproduce that accepted baseline
- old experiments remain comparable only if preserved as refs/branches/tags

Strong sentence for the team:

> `main` is not the museum of every experiment. It is the accepted baseline.

---

## Suggested naming patterns

### Branches
- `exp/isolation-forest-baseline`
- `exp/factor-analysis-v2`
- `exp/xgb-window-shift`
- `feature/add-change-point-stage`
- `release/demo-v1`

### Tags
- `winner/isolation-forest-v1`
- `winner/xgb-shift-v3`
- `milestone/demo-ready-v1`
- `release/v1.0`

---

## What you learned in this doc

- the winner flow from experiment to accepted baseline
- how to validate before promotion
- merge vs tag strategy
- what `main` gets after merge
- why `main` should not contain every experiment as current state

## Read this next

Read **PRESENTATION_GUIDE.md**.

## When to come back to this doc

Come back when the team is deciding how to formalize a winner.
