# Package Contents

Two versions of the same write-up are included. Pick the one that matches how you are uploading.

| File | Use when |
| --- | --- |
| `Data_Versioning_Knowledge_Share.md` | Uploading the whole folder (keeps the `images/` subfolder). Image links are relative paths. |
| `Data_Versioning_Knowledge_Share_CDN.md` | Uploading a single file to Teams. Images load from hosted URLs, so no attachments are needed. |

## Image assets

All four diagrams are sourced from published documentation and tutorials; none are AI-generated.

| File | Shows | Source |
| --- | --- | --- |
| `images/01_dvc_git_two_tracks.png` | Pointer file to the Git server, actual data to remote storage | DVC docs graphic via MLOps Guide |
| `images/02_dvc_metadata_workspace.png` | Metadata and config to GitHub, data to local cache and S3 | DevOpsCube DVC tutorial |
| `images/04_workspace_cache_remote.png` | Workspace, cache and remote storage loop | DVC remotes diagram, DataCamp materials |
| `images/03_git_commit_data_model_timeline.png` | Each commit pinned to a data, features and model version | DVC docs, "Versioning Data and Models" |

## Hosted image URLs

If you would rather paste images inline in the Teams post body:

1. https://files.manuscdn.com/user_upload_by_module/session_file/95857611/ygVbDzGfMhUtZqML.png
2. https://files.manuscdn.com/user_upload_by_module/session_file/95857611/iSEZeXLNMNsUVukF.png
3. https://files.manuscdn.com/user_upload_by_module/session_file/95857611/ReXZyufSWvsEafSu.png
4. https://files.manuscdn.com/user_upload_by_module/session_file/95857611/DgBfhXvWwNAUumLI.png
