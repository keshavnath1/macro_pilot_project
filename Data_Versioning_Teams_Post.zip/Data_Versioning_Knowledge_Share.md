# Why We Version Our Data

## Where we are today

By the time a dataset is ready for training, the hard work is already done. The data has been ingested, transformed, centralized, analyzed, and turned into features. That is a lot of effort invested in the initial steps of an MLOps pipeline — and the feature engineering part in particular represents progress no one wants to lose.

Teams rarely work alone on this. Several ML engineers or data engineers often work with the same datasets and the same data sources, and each ends up producing their own feature sets. Those feature sets need to be shareable so people can experiment, give feedback, make suggestions, and genuinely collaborate on the data work that has been done.

## What goes wrong without versioning

The difficulty is bookkeeping. Without a versioning discipline, teams are not quite sure how to keep up with their datasets, associate them with the models they produced, or keep track of the experiments and code used during training. What fills the gap is improvised: zip files saved in Google Drive, a large number of S3 buckets with names like `dataset_one` and `dataset_two_three`, and a spreadsheet somewhere where everyone tries to maintain the link between a zip file and the model it belongs to.

That approach gets messy as more experiments accumulate, and it fails at exactly the wrong moment — when experiments finally need to be compared so one candidate can be promoted to production. The worst outcome is reaching deployment or a further round of testing and being unable to reproduce a model because it is no longer clear which features were used. A model that cannot be reproduced cannot be used.

## The question this raises

If code has had a reliable answer to this problem for years, why should data be any different? In Git, every change to code can be traced back to where it was made, when it was made, and what it was. The question is simply how to get the same guarantee for datasets — the ability to return to any previous state the data was in and regenerate exactly the same model.

## How data versioning answers it

Data versioning applies the same concepts as code versioning, optimized for data. The mechanism is a separation of concerns: a small metadata file travels through Git, while the actual data lives in storage built for size.

![DVC and Git working side by side: the pointer file goes to the Git server while the actual data goes to remote data storage](images/01_dvc_git_two_tracks.png)

*Source: DVC official documentation graphic, via MLOps Guide [1]*

The tool creates a directory that works a little like a `.git` directory: it holds the metadata associated with each version of a dataset, so it does not clog up a lot of space. When a dataset is added to version control, a small `.dvc` file is produced alongside it containing a **hash that represents the state of the data at the time of the commit**. Editing the data and adding it again records the new state; adding it when nothing has changed simply reports that everything is already in sync.

That metadata file and the configuration file are what get committed to Git. The data itself is versioned into a local cache and synchronized with remote storage such as an S3 bucket.

![The metadata pointer file and config travel through Git to GitHub, while the actual data is versioned into a local cache and pushed to S3](images/02_dvc_metadata_workspace.png)

*Source: DevOpsCube DVC tutorial [2]*

Connecting that remote storage is conceptually close to connecting to a repository or setting up a remote branch — not quite the same concept, but similar. Once credentials to the storage account are in place, changes move in both directions: **push** sends local dataset changes up to remote storage, and **pull** brings remote changes down to the local machine.

| Layer | What lives there | How it moves |
| --- | --- | --- |
| Local workspace | The real file being worked on | Checked out by the tool |
| Local cache | A copy identified by its content hash | Written when data is added |
| Git remote | The `.dvc` metadata file and config — small text | `git push` / `git pull` |
| Data remote | The actual bytes, in S3 or similar object storage | `dvc push` / `dvc pull` |

Crucially, only the parts that changed are transferred. With object storage the data inside is usually large, so tracking small changes to a dataset of images or videos means an entire dataset never has to be downloaded again — only the parts that are different.

![Workspace, cache and remote storage, showing changes staged into the cache and uploaded to the remote](images/04_workspace_cache_remote.png)

*Source: DVC remotes diagram, DataCamp course materials [4]*

Several open-source tools support this practice and appear regularly in industry job descriptions, some with paid tiers for additional support or features.

| Tool | Note |
| --- | --- |
| DVC (Data Version Control) | Widely used; clear error messages |
| Neptune | Commonly encountered |
| Pachyderm | Frequently referenced |
| Dolt | Also in use |

Parts of the workflow can be automated, but data versioning is largely a deliberate, manual practice. Because these tools are cutting edge and relatively new, reading the documentation during setup is worth the time.

## The value we get from it

The payoff shows up in four places.

**Reproducibility becomes guaranteed rather than hoped for.** A specific data hash or data state is associated with a specific model, so any previous state can be restored and the exact same model regenerated. Every commit pins a matching data, feature, and model version together.

![A commit timeline where each hash corresponds to a specific data, features and model version](images/03_git_commit_data_model_timeline.png)

*Source: DVC official documentation, "Versioning Data and Models" [3]*

**Experiment tracking gets much easier.** Instead of a spreadsheet mapping zip files to models, the association is built into the history — which matters most when experiments have to be compared and one has to be chosen for production.

**There is freedom to experiment with features and schema.** More feature engineering scripts can be written, more datasets generated, and more models tried, without worrying about which dataset went with which model. Data versioning is one of the main tenets of MLOps precisely because it saves so much time when a model goes to production or is retrained.

**Time and resources are saved directly.** Changes between datasets are tracked, rather than bundling up an entire dataset just because a few images have changed.

Taken together, the benefit is not only technical. Versioning datasets frees up mental space and gives far more freedom and flexibility in how models are trained and retrained.

## References

[1] [What is DVC? — MLOps Guide](https://mlops-guide.github.io/Versionamento/dvc/)
[2] [Data Version Control (DVC) Tutorial For Beginners — DevOpsCube](https://devopscube.com/dvc-tutorial/)
[3] [Versioning Data and Models — DVC Documentation](https://dvc.org/doc/use-cases/versioning-data-and-models)
[4] [Configuring DVC Remotes — DataCamp course materials](https://campus.datacamp.com/)
