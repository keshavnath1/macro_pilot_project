# Prompt Engineering Concepts — Visual Guide

> This guide explains the three core prompt engineering techniques used in the SAS-to-PySpark migration pipeline. Each concept is shown visually first, then mapped directly to how it appears in the pipeline.

---

## Concept 1: The Anatomy of a Prompt

Every prompt in this pipeline is not a single sentence. It is a **structured composition of seven components**, each doing a specific job.

![Prompt Components](./prompt_components.png)

| Component | What it does | How we use it in the pipeline |
|---|---|---|
| **Persona** | Tells the LLM what role to adopt | `"You are an expert SAS Migration Architect with deep knowledge of PySpark Window functions"` |
| **Instruction** | The exact task to perform | `"Freely discover all transformation patterns in the attached SAS code"` |
| **Context** | Explains the *why* behind the task | `"This is Stage 2b of a 5-stage pipeline. Stage 2a has already produced the lineage DAG."` |
| **Format** | Locks down the output structure | `"Return ONLY a valid YAML block matching this exact schema: ..."` |
| **Audience** | Sets the level of the response | `"The output will be consumed by the next automated prompt, not a human"` |
| **Tone** | Controls style | `"Be precise and technical. Do not explain what SAS does — focus on the PySpark equivalent."` |
| **Data** | The actual input to process | The `sas_code_block` field extracted from `policy_registry.yaml` |

**Why this matters:** Without a Format component, the LLM invents its own output structure and the next prompt in the chain cannot parse it. Without a Persona, the LLM defaults to a generic assistant tone and misses domain-specific edge cases like null handling in `RETAIN` loops.

---

## Concept 2: Tree of Thought — Exploring Multiple Paths

Standard prompting asks the LLM for one answer immediately. **Tree of Thought** forces the LLM to explore multiple reasoning paths, rate each one, and prune the bad ones before committing to a final answer.

![Tree of Thought](./tree_of_thought.png)

> Each node in the tree is a "thought" — an intermediate reasoning step. Green nodes are promising paths. Red nodes are dead ends that get pruned. The LLM only follows the path that survives all the way to the bottom.

**Where we use it in the pipeline:**

**Prompt 1 — Column Graph Builder** uses Tree of Thought to build the Dataset Lineage DAG. Instead of guessing which datasets are related, the LLM explores multiple possible dependency chains, rates each one against the execution trace, and outputs only the verified lineage.

**Prompt 2 — Pattern Discoverer** uses Tree of Thought to identify transformation patterns. The LLM considers multiple candidate pattern names for each SAS block (e.g., "Is this a stateful loop, or a window aggregation, or a simple sort?"), rates each interpretation, and commits to the one best supported by the code structure.

```
SAS RETAIN block
    ├── Path A: Stateful loop (mapPartitions)   ← rated HIGH confidence
    ├── Path B: Window function (lag/lead)      ← rated MEDIUM confidence
    └── Path C: Simple sort + cumsum            ← rated LOW confidence, pruned
                        ↓
            Final answer: Stateful loop
```

---

## Concept 3: Self-Consistency — Sampling from Multiple Paths

Where Tree of Thought explores one tree deeply, **Self-Consistency** runs the same question multiple times independently and takes a majority vote. This is especially powerful when the correct answer is ambiguous and a single run might land on the wrong path.

![Self-Consistency](./self_consistency.png)

> Three independent LLM runs produce different reasoning chains. Two agree on the same answer. The majority vote wins. The outlier is discarded.

**Where we use it in the pipeline:**

**Prompt 3 — Self-Consistency Classifier** applies this technique to every HIGH-complexity pattern in `policy_registry.yaml`. The LLM runs 5 independent internal classifications for each pattern and tallies the votes:

```json
{
  "pattern": "retain_by_group_state",
  "tally": {
    "stateful_mapPartitions": 4,
    "window_function_lag":    1
  },
  "decision": "ACCEPT",
  "winning_pattern": "stateful_mapPartitions"
}
```

A **4/5 majority** triggers `ACCEPT` and the pattern proceeds to code generation. A **3/5 or lower split** triggers `ESCALATE TO MCTS` — the pattern is too ambiguous for a simple vote and needs the full Monte Carlo search to resolve it.

**Why not just ask once?** A single classification run on a `RETAIN` loop with nested `BY` groups and null guards has roughly a 60–70% chance of picking the right PySpark approach. Five independent runs with majority voting pushes that to over 90%.

---

## Concept 4: MCTS — When the Vote Fails

When Self-Consistency cannot reach a majority, the pattern is escalated to the **MCTS Fallback Loop**. This is a 4-step Monte Carlo Tree Search that simulates different PySpark approaches, evaluates which ones would fail, and backtracks to find a winning path.

```
MCTS 1 — Selection
  Read policy_registry.yaml. Identify the escalated pattern.
  Select the most promising unexplored PySpark approach.
        ↓
MCTS 2 — Expansion
  Write a candidate PySpark implementation for the selected approach.
        ↓
MCTS 3 — Simulation
  Mentally simulate running the candidate against the SAS ground truth.
  Predict: will this produce divergent rows? Where will it fail?
        ↓
MCTS 4 — Backpropagation
  If simulation predicts failure → score this path LOW, backtrack to MCTS 1.
  If simulation predicts success → output the final implementation.
```

The MCTS loop runs until it finds a path scored as viable, or until it has exhausted the candidate approaches and must report the best available option for human review.

---

## How the Three Techniques Map to the Pipeline

```
Stage 2a: Column Graph Builder
  └── Tree of Thought → explores dependency paths → outputs Lineage DAG

Stage 2b: Pattern Discoverer
  └── Tree of Thought → explores pattern interpretations → outputs policy_registry.yaml

Stage 3: Self-Consistency Classifier
  └── Self-Consistency (5 runs) → majority vote → ACCEPT or ESCALATE

Stage 3 Fallback: MCTS Loop
  └── Monte Carlo Tree Search (4 steps) → simulation + backpropagation → final method

Stage 4: PySpark Code Generator
  └── Sequential Sampling (3 candidates) → ranked output → production PySpark

Stage 5: Repair Prompt
  └── Evaluator-Optimizer loop → diff report → minimal patch
```

**The key insight:** We never ask the AI to "just write the code." We force it to think, explore, vote, and simulate before any code is produced. The result is PySpark that passes a diff-based regression test against the original SAS output on the first or second attempt — not after ten rounds of manual debugging.
